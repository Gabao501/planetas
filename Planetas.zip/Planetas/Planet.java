package br.com.unicuritiba.torneiodopoder;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Planet {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nome;
    private double diametro;
    private double peso;
	public void setId(Long id2) {
		
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getDiametro() {
		return diametro;
	}
	public void setDiametro(double diametro) {
		this.diametro= diametro;
	}
	public double Peso() {
		return peso;
	}
	public void Peso(double peso) {
		this.peso = peso;
	}
    
    // Getters e Setters
    // ...
}
