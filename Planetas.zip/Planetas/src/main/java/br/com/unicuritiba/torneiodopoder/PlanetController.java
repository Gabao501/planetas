package br.com.unicuritiba.torneiodopoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/planets")
public class PlanetController {
    
    @Autowired
    private PlanetRepository planetRepository;
    
    @GetMapping("/")
    public List<Planet> getAllPlanets() {
        return planetRepository.findAll();
    }
    
    @GetMapping("/{id}")
    public Planet getPlanetById(@PathVariable Long id) {
        return planetRepository.findById(id).orElse(null);
    }
    
    @PostMapping("/")
    public Planet addPlanet(@RequestBody Planet planet) {
        return planetRepository.save(planet);
    }
    
    @PutMapping("/{id}")
    public Planet updatePlanet(@PathVariable Long id, @RequestBody Planet planet) {
        planet.setId(id);
        return planetRepository.save(planet);
    }
    
    @DeleteMapping("/{id}")
    public void deletePlanet(@PathVariable Long id) {
        planetRepository.deleteById(id);
    }
}
