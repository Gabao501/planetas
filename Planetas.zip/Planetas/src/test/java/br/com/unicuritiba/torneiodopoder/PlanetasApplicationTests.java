package br.com.unicuritiba.torneiodopoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanetasApplicationTests {

	@Test
	void contextLoads() {
	}

}
